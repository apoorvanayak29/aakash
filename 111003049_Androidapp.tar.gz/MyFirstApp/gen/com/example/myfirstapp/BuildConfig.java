/** Automatically generated file. DO NOT MODIFY */
package com.example.myfirstapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}