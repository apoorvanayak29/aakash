package com.example.myfirstapp;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.DatabaseActivity;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.RadioButton;





public class ResistanceActivity extends Activity{
	public final static String EXTRA_MESSAGE = "com.example.myfirstapp.MESSAGE";
	@SuppressLint("NewApi")

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_resistance);
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            // Show the Up button in the action bar.
            getActionBar().setDisplayHomeAsUpEnabled(true);
		}
	}
	String text_new1, text_new2, text_new3, text_new4;

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.resistance, menu);
		return true;
	}
	public void digitOne(View view) {
		DatabaseActivity mydb = new DatabaseActivity(this);
	//	Intent intent1 = new Intent(this, ResistanceResultActivity.class);
		mydb.openDataBase();
		boolean checked = ((RadioButton) view).isChecked();
		RadioButton rb = (RadioButton) findViewById(view.getId());
		CharSequence textView = rb.getText();
		//Globals global = ((Globals)getApplicationContext());
		text_new1 = mydb.onefromdatabase(textView);
		mydb.close();
		
		//intent1.putExtra(EXTRA_MESSAGE, text);
	    //startActivity(intent1);
		
		
		
		
		
		
	//	boolean checked = ((RadioButton) view).isChecked();
//		RadioButton rb;
//		rb = (RadioButton) findViewById(R.id.gold);
		//RadioButton rb;

	//	RadioButton rb = (RadioButton) findViewById(R.id.rb);
//		CharSequence textView = rb.getText();
//		int num1;
		//String text;
//		String text = mydb.onefromdatabase(textView);
		
	    
	    
	    
	    
	    
	    
	    
		
		//view.getId();
		//View btngold;
		//btngold =  findViewById(R.id.gold);
		
		//String s = v.getID()
		//if(v == btngold)
	//	{
			//String str = gold;
			//String data = mydb.onefromdatabase(R.id.gold);
		//}
		//String data = mydb.onefromdatabase(str);
		//mydb.close();
	}
	
	public void digitTwo(View view) {
		DatabaseActivity mydb = new DatabaseActivity(this);
	//	Intent intent1 = new Intent(this, FormulaResultActivity.class);
		mydb.openDataBase();
		boolean checked = ((RadioButton) view).isChecked();
		RadioButton rb = (RadioButton) findViewById(view.getId());
		CharSequence textView = rb.getText();
		text_new2 = mydb.twofromdatabase(textView);
		mydb.close();
		//intent1.putExtra(EXTRA_MESSAGE, text_new2);
	 //   startActivity(intent1);
		
	//	int two = mydb.twofromdatabase();
	//	mydb.close();
	}
	public void digitThree(View view) {
		DatabaseActivity mydb = new DatabaseActivity(this);
		//Intent intent1 = new Intent(this, FormulaResultActivity.class);
		mydb.openDataBase();
		boolean checked = ((RadioButton) view).isChecked();
		RadioButton rb = (RadioButton) findViewById(view.getId());
		CharSequence textView = rb.getText();
		text_new3 = mydb.threefromdatabase(textView);
		//int three = mydb.threefromdatabase();
		mydb.close();
	}
	
	public void digitFour(View view) {
		DatabaseActivity mydb = new DatabaseActivity(this);
		//Intent intent1 = new Intent(this, FormulaResultActivity.class);
		mydb.openDataBase();
		boolean checked = ((RadioButton) view).isChecked();
		RadioButton rb = (RadioButton) findViewById(view.getId());
		CharSequence textView = rb.getText();
		text_new4 = mydb.fourfromdatabase(textView);
		//int three = mydb.threefromdatabase();
		mydb.close();
	}
	
	
	
	public void callCalculate(View view) {
		int num1, num2, mul;
		double cal;
		String text;
		Intent intent1 = new Intent(this, ResistanceResultActivity.class);
		num1 = Integer.parseInt(text_new1);
		num2 = Integer.parseInt(text_new2);
		mul = Integer.parseInt(text_new3);
		if(num1 == -1 || num2 == -1 || num1 == -2 || num1 == -3 || mul == -3)
		{
			text = "" + "Invalid";
		
		}
		else{
			cal = (num1 * 10 + num2) * Math.pow(10, mul) ; 
			if(text_new4 .equals("-"))
			{
				text = ""+cal+"Ω";
			}
			else
			{
				text = ""+cal+text_new4+"Ω";
			}
		}
		intent1.putExtra(EXTRA_MESSAGE, text);
	    startActivity(intent1);
		
		
		//DatabaseActivity mydb = new DatabaseActivity(this);
		//Intent intent1 = new Intent(this, FormulaResultActivity.class);
		//mydb.openDataBase();
		
		
	}
		

}
