package com.example.myfirstapp;

public interface Globals {
	String text_new1 = "";
	String text_new2 = "";
	String text_new3 = "";
	String text_new4 = "";

}
