package com.example.myfirstapp;

import java.io.IOException;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.database.SQLException;
import android.database.sqlite.DatabaseActivity;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class FormulaActivity extends Activity {
	public final static String EXTRA_MESSAGE = "com.example.myfirstapp.MESSAGE";
	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_formula);
        TextView tview = (TextView) findViewById(R.id.hello);
		DatabaseActivity mydb = new DatabaseActivity(this);
		try {
			 
			mydb.createDataBase();
			 
			} catch (IOException ioe) {
			 
			throw new Error("Unable to create database");
			 
			}
			 
			try {
			 
			mydb.openDataBase();
			 
			}catch(SQLException sqle){
			 
			throw sqle;
			 
			}
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            // Show the Up button in the action bar.
            getActionBar().setDisplayHomeAsUpEnabled(true);
        }
		getIntent();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.formula, menu);
		return true;
	}

	public void sendMessage(View view) {
		DatabaseActivity mydb = new DatabaseActivity(this);
	//	Intent intent1 = new Intent(this, DatabaseActivity.class);
		Intent intent1 = new Intent(this, FormulaResultActivity.class);
		mydb.openDataBase();
		EditText editText = (EditText) findViewById(R.id.edit_message);
		String message = editText.getText().toString();
		
		
		
		//Cursor cur = mydb.query("formula",null, null, null, null, null, null);
	      // cur.moveToFirst();
	        //while (cur.isAfterLast() == false) {
	          //  tview.append("n" + cur.getString(1));
	       	    //cur.moveToNext();
	        //}
	        //cur.close();
		String text= mydb.getAppCategorydetail(message);
		mydb.close();
		intent1.putExtra(EXTRA_MESSAGE, text);
	    startActivity(intent1);
		
		
		
	//	EditText editText = (EditText) findViewById(R.id.edit_message);
	  //  String message = editText.getText().toString();
	    //select formula from phy_formula where formula like '%message%';
	    

		
	}
	
	
}
